#' @title launch
#' @description
#' Launches the imperial malaria model. The user may specifiy the executable, model files, model parameters,
#' site files, demograhpy and popultion or use the defualt options included within the package. Default options
#' inlude the Executable "Exe name" "Version" "Date" "Link", and the median parameters "Paper link"
#'
#' @param output_folder Full address for output. eg. \code{"c:/users/me/Output_folder"}.
#' @param name Name of output file. eg. \code{"Output_name"}.
#' @param options Model options. These are the command line parameters for the executable. The \code{Options} argument
#' can be specified in one of two formats:
#' \itemize{
#' \item{\code{string}}{  In the format \code{"Par1 10 Par2 11"}.
#' Parameters not explicitly defined in the input files can be included after the word add in this
#' vector \code{"Par1 10 Par2 11 add Par99 12"}}
#' \item{\code{data.frame}}{  The data.frame must contain two columns
#' the first being named \code{par} and the second being named \code{value}. The "add" term can be used by
#' including it in the appropriate position on the \code{par} column, with an associated \code{NA} in the  \code{value} column.}
#' }
#'
#' @param draw Parameter set to use. A value between 0 and 50, where 0 dentotes the median parameter
#' set and 1-50 constitutes 50 draws from the posterior fit.
#' @param return_output Load and return output as dataframe, default = \code{TRUE}
#' @param overwrite Overwrite previous model run with the same name & address
#' @param site  Site dataframe There are five default options available. Each of these sites has a default of no prior
#' interventions/treatment and baseline prevalence of 30%.
#' \itemize{
#' \item{\code{"mlgts::perennial"}}{ A Perennial site (based on Equateur, DRC)}
#' \item{\code{"mlgts::seasonal"}}{ A Seasonal site (based on Upper East, Ghana)}
#' \item{\code{"mlgts::highly_seasonal"}}{ A Highly seasonal site (based on Fatick, Senegal)}
#' \item{\code{"mlgts::bimodal"}}{ A Bimodal seasonality profile (based on Tanga Tanznia)}
#' \item{\code{"mlgts::no_season"}}{ A flat seasonality profile}
#' }
#' @param demog Demography data.frame eg. \code{"mlgts::flat_demog"}.
#' @param pop Population data.frame eg. \code{"mlgts::generic_pop"}.
#' @param output_vars Optional data frame for custom output vars with columns:
#' \itemize{
#' \item{\code{"type"}}{Output type e.g. prev, prop etc}
#' \item{\code{"lower"}}{Lower age range}
#' \item{\code{"upper"}}{Upper age range}
#' \item{\code{"name"}}{Variable name}
#' }
#' @param exe Full address of executable to run. If NULL use default package executable.
#'
#' @return A list of \code{$X} = Inputs and \code{$Y} = Output. Output may either be the output text file if the model has run, or the cout file if no output is found.
#' @export
launch <- function(name, output_folder = NULL, options = "",
                   draw = 0, return_output = TRUE, overwrite = TRUE,
                   site = mlgts::bimodal,
                   demog = mlgts::flat_demog,
                   pop = mlgts::generic_pop,
                   output_vars = NULL,
                   exe = NULL,
                   mf_loc = NULL){

  # Define the executable
  if(is.null(exe)){
    exe = system.file("bin", "irs_restructure.exe", package = "mlgts")
  }

  # Define the model files location
  if(is.null(mf_loc)){
    mf_loc = system.file("model_files", package = "mlgts")
  }

   # Create temporary directory
  td <- paste0(tempdir(), "/", hash())
  dir.create(td)

  # Copy model files as required
  fc1 <- file.copy(from = mf_loc, to = td, recursive = TRUE)
  model_file_folder <- paste0(td, "/model_files")

  # Overwrite output vars if provided
  if(!is.null(output_vars)){
    df_save(output_vars, paste0(model_file_folder, "/output_vars.txt"))
  }

  # Add site, demog, pop and parameter .txt files
  df_save(site, paste0(model_file_folder, "/sites/site.txt"))
  df_save(demog, paste0(model_file_folder, "/demography/demog.txt"))
  df_save(pop, paste0(model_file_folder, "/population/pop.txt"))
  mpf <- system.file("parameters", paste0("model_parms_", draw, ".txt"), package = "mlgts")
  fc2 <- file.copy(from = mpf, to = model_file_folder)
  fc3 <- file.rename(paste0(model_file_folder, "/model_parms_", draw, ".txt"),
                     paste0(model_file_folder, "/model_parms.txt"))
  if(any(!c(fc1, fc2, fc3))){
    stop(paste("Files not successfuly copied or renamed in temp dir", td))
  }

  # Create a temporary directory to store results if one is not specified
  if(is.null(output_folder)){
    output_folder <- paste0(td, "/output")
    dir.create(output_folder)
  }

  # Check if output file exists
  overwrite_output(output_folder, name, overwrite)

  # Write options to include specified model parameter file
  options <- format_options(options)

  # Input argument (Command line)
  runstring <- c(model_file_folder,
                 "default_parms.txt",
                 "sites/site.txt",
                 "demography/demog.txt",
                 "population/pop.txt",
                 output_folder,
                 name,
                 options)

  # Run model
  code <- suppressWarnings(system2(command = exe, args = runstring))
  # Check for code error
  if(code != 0){
    err_message <- load_cout(output_folder, name)
    stop("Running command fail with possible error: ", err_message, "Check cout for more details")
  }

  # Summarise inputs
  input <- list(exe = exe, site = site, demog = demog,
                pop = pop, output = paste0(output_folder, "/", name),
                options = options,
                mf_loc = mf_loc)

  # Load output (or cout file if the run did not complete)
  if(return_output){
    output <- load_output(paste0(output_folder, "/", name, ".txt"))
    return(list(input = input, output = output))
  }
}






