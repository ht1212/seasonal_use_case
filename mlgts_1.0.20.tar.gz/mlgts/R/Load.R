#' @title
#' Load output
#' @description
#' Searches for and load output text file from a model run
#'
#' @param file Output file
#' @return Output text file loaded as a data.frame
load_output <- function(file){
  if(file.exists(file)){
    check_recent(file)
    message('Returning inputs and output file.')
    out <- utils::read.table(file = file, sep = '\t', header = TRUE)
  } else {
    stop('Could not find model output file')
  }

  return(out)
}

#' @title
#' Load cout file (error)
#' @description
#' Searches for and loads the cout file in the case of an error running the exe
#'
#' @inheritParams launch
#' @return Final line of .cout file, which often contains a useful error message
load_cout <- function(output_folder, name){
  cout <- paste0(output_folder, '/', name, '.cout')

  if(file.exists(cout)){
    out <- (matrix(scan(cout, sep = '\t', what = '', quiet = TRUE)))
      Error <- utils::tail(out, 1)
    } else {
      Error <- ('Could not find .cout file, or model output')
  }
  return(Error)
}

#' @title
#' Overwrite output
#' @description
#' Searches for existing output in the root folder with the given run name.
#' Checks for overwrite permission.
#'
#' @inheritParams launch
#' @param overwrite Boolean should existing output (if any) be overwritten
overwrite_output <- function(output_folder, name, overwrite){
  out <- paste0(output_folder, '/', name, '.txt')

  if(file.exists(out) & overwrite){
    message('Overwriting existing output with the same OutputName')
  }
  if(file.exists(out) & !overwrite){
    stop('Output with name:', name, ' already exists and Overwrite = FALSE')
  }
}

#' @title
#' Check output is recent
#' @description
#' Checks that the output file being loaded is current (< 1 day old) and produces
#' a warning if not.
#'
#' @param output_file The address of the output file being loaded.
check_recent <- function(output_file){
  made <- as.Date(file.info(output_file)$mtime)
  now <- as.Date(Sys.time())
  if(as.numeric(now - made) > 0){
    warning("Output file being returned is more than 1 day old. The current run with the
  same OutputName likely failed. Consider deleting the old run, or renaming the current run.")
  }
}
