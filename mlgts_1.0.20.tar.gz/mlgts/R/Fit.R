#' @title
#' Fitting mosquito density.
#' @description
#' Provides basic functionality for fitting the mosquito density (total_M) parameter in a site file
#' to specified data (usually prevalence or incidence) at given time point(s).
#' This has been designed for use with the compact model output style (ie \code{Options  = "output_type 1"}),
#' also, this must not be combined with inbuilt refitting functionality (ie run with \code{Options  = "recalculate 0"}).
#' Please refer to the Fitting vignette for more guidance.
#'
#' @param variable The name of the output variable to be fitted (eg: "prev_2_10" or "clin_inc_all"). This must be
#' a variable name in the output.
#' @param target The target value(s) of the specified variable. These may be a single value or vector.
#' @param rows The output row(s). These may be a single value or vector.
#' @param tolerance The desired tolerance of the fit. The fit being succesful when the \code{abs(variable - target) < tolerance)}.
#' @param interval The interval to be searched (see \link[stats]{uniroot} for more information, note: \code{extendInt = 'upX'}).
#' @param maxiter The maximum number of iterations (model runs) to search for. Importantn for keeping timescales reasonable
#' when fitting many sites.
#' @param verbose Output is printed during each iteration, including the current total_M and the output target value.
#' @param extendInt Extend the search interval, see \link[stats]{uniroot} for more details
#' @param check.conv Error or warning for convergence failure, see \link[stats]{uniroot} for more details
#' @param ... Additional arguments to \code{fit()}
#' @inheritParams launch
#'
#' @export
fit_m <- function(variable = 'prev_2_10', target, rows,
                  options = "",
                  tolerance = 0.05, interval = c(0.0001,10), maxiter = 10,
                  verbose = FALSE, extendInt = "no", check.conv = FALSE, ...){

  stopifnot(all(target >= 0), tolerance > 0, maxiter > 0)

  if(verbose){
    message("~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~")
    message("Fitting ", variable, " = ", paste(target, collapse = " "),
            " in row(s) ", paste(rows, collapse = " "), ".")
  }

  if(all(target == 0)){
    new_M <- 0
  } else {
    # Run the root finding function
    fit <- stats::uniroot(fit, interval = interval, target = target, variable = variable,
                   options = options,
                   rows = rows, tolerance = tolerance,
                   extendInt = extendInt,
                   check.conv = check.conv, maxiter = maxiter, verbose = verbose,
                   ...)
    new_M <- round(fit$root, 5)
  }

  message('Fitting, complete. Total_M = ', new_M, ' .')
  return(new_M)
}


#' @title
#' Internal: Fitting mosquito density.
#' @description
#' Internal function provided to \link[stats]{uniroot} for fitting mosquito densities
#'
#' @param total_M The mosquito density for the current model run
#' @inheritParams fit_m
#' @param ... Additional arguments to \code{fit()}
fit <- function(total_M, target, variable, rows, tolerance, verbose, options, ...){
  # Have an upper limit on total M of ~200
  if(total_M >= 200){
    return(0)
  }
  options <- paste(paste("total_M", total_M, sep = ' '), options, sep = ' ')
  temp <- suppressMessages(launch(name = 'Fitting_output',
                                  options = options,
                                  ...))

  if(verbose){
    message("Current total_m = ", round(total_M, 4))
    message("Current iteration ", variable, " = ", paste(round(temp$output[rows, variable], 4), collapse = " "), ".")
  }

  if(sum(abs(temp$output[rows, variable] - target)) < tolerance & all(temp$output[rows, variable] > 0)){
    return(0)
  } else {
    # Return an arbitrarily poor fit if there is transmission and our model output is zero
    if(any((temp$output[rows, variable] == 0) & (target != 0))){
      message("Zero transmission")
      return((total_M - 100) * 100)
    }
    message("Current absolute difference = ", sum(abs(temp$output[rows, variable] - target)))
    return(sum(temp$output[rows, variable] - target))
  }

  if(verbose){
    message("~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~")
  }
}

