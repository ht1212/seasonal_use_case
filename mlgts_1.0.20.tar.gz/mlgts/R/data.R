#' Bimodal site
#'
#' A site with representative bimodal seasonality
#'
#' @format A data frame with 16 rows and 2 variables:
#' \describe{
#'   \item{V1}{parameter names}
#'   \item{V2}{parameter values}
#' }
"bimodal"

#' Highly seasonal site
#'
#' A site with representative highly seasonal seasonality
#'
#' @format A data frame with 16 rows and 2 variables:
#' \describe{
#'   \item{V1}{parameter names}
#'   \item{V2}{parameter values}
#' }
"highly_seasonal"

#' Seasonal site
#'
#' A site with representative seasonal seasonality
#'
#' @format A data frame with 16 rows and 2 variables:
#' \describe{
#'   \item{V1}{parameter names}
#'   \item{V2}{parameter values}
#' }
"seasonal"

#' Perennial site
#'
#' A site with representative perennial seasonality
#'
#' @format A data frame with 16 rows and 2 variables:
#' \describe{
#'   \item{V1}{parameter names}
#'   \item{V2}{parameter values}
#' }
"perennial"

#' No season site
#'
#' A site with no seasonality
#'
#' @format A data frame with 16 rows and 2 variables:
#' \describe{
#'   \item{V1}{parameter names}
#'   \item{V2}{parameter values}
#' }
"no_season"

#' Flat demography
#'
#' A default flat demography input
#'
#' @format A data frame with 2 rows and 5 variables:
#' \describe{
#'   \item{V1}{year}
#'   \item{V2}{age group lower bound}
#'   \item{V3}{age group upper bound}
#'   \item{V4}{inflow}
#'   \item{V5}{outflow}
#' }
"flat_demog"

#' Generic demography
#'
#' A default generic demography input
#'
#' @format A data frame with 2 rows and 5 variables:
#' \describe{
#'   \item{V1}{year}
#'   \item{V2}{age group lower bound}
#'   \item{V3}{age group upper bound}
#'   \item{V4}{inflow}
#'   \item{V5}{outflow}
#' }
"generic_demog"

#' Generic population growth
#'
#' Yearly population size (relative to index year)
#'
#' @format A data frame with 151 rows and 2 variables:
#' \describe{
#'   \item{V1}{year}
#'   \item{V2}{relative population size}
#' }
"generic_pop"
