#' @title
#' Flexible IRS inputs
#' @description
#' Formats yearly variable (future) IRS coverages to input string required for command-line use or as part
#' of the \code{Options} argument in the \code{\link{launch}} function. Use after the word \code{add}.
#'
#' @param years The future (time 0 onwards) output years for the simulation being run.
#' @param coverage A vector of IRS coverage inputs, one for each year specified in years
#' @return A string containing command line options.
#' @examples
#' # Specify years
#' Y <- 0:5
#' # Specify coverage
#' C <- c(0, 0, 0.2, 0.4, 0.6, 0.8)
#' # Create input string
#' IRS_input_string <- irs_flexible_input(years = Y, coverage = C)
#'
#' @export
irs_flexible_input <- function(years, coverage){

  # Check inputs
  stopifnot(min(years) == 0)
  stopifnot(length(years) == length(coverage))
  stopifnot(any(coverage >= 0))

  # Cycle through years setting coverage for each
  irs_cov_options<-paste0('irs 1 irs_coverage ', coverage[1], ' irs_max_rounds 1')
  for(i in 2:length(years)){
    irs_cov_options<-paste0(irs_cov_options,
                            ' irs_', i, ' ', 1,
                            ' irs_coverage_', i, ' ', coverage[i],
                            ' irs_start_', i, ' ', years[i],
                            ' irs_max_rounds_', i, ' ', 1)
  }

  return(irs_cov_options)
}

#' @title
#' Flexible ITN inputs
#' @description
#' Formats yearly variable (future) ITN coverages to input string required for command-line use or as part
#' of the \code{Options} argument in the \code{\link{launch}} function. Use after the word \code{add}.
#'
#' @param years The future (time 0 onwards) output years for the simulation being run.
#' @param coverage A vector of IRS coverage inputs, one for each year specified in years
#' @param num_runs This must equal the corresponding parameter in the input file. ITN distributions
#' are smoothed over populations of num_runs so these values interact.
#' @return A string containing command line options.
#' @examples
#' # Specify years
#' Y <- 0:5
#' # Specify coverage
#' C <- c(0, 0, 0.2, 0.4, 0.6, 0.8)
#' # Specify number of runs
#' NR <- 3
#' # Create input string
#' IRS_input_string <- itn_flexible_input(years = Y, coverage = C, num_runs = NR)
#' @export
itn_flexible_input <- function(years, coverage, num_runs){

  # Check inputs
  stopifnot(min(years) == 0)
  stopifnot(length(years) == length(coverage))
  stopifnot(any(coverage >= 0))
  stopifnot(num_runs > 0)

  # Define which population will be implementing ITNs each year
  Implementing_pop <- rep(1:num_runs, length.out = length(years))
  # Create a coverage matrix (Year x pop)
  Covs <- matrix(0, nrow=length(years), ncol = num_runs)
  for(i in seq_along(years)){
    Covs[i, Implementing_pop[i]] <- coverage[i]
  }

  # Create text input for command line (Options)
  itn_cov_options <- paste0('itn_cov_', rep(years, num_runs), '_',
                          rep(0:(num_runs - 1), each=length(years)), ' ',
                          as.vector(Covs), collapse = ' ')
  itn_cov_options <- paste("itn 0 itn_flexible 1", itn_cov_options)
  return(itn_cov_options)
}


#' @title
#' Flexible Treatment inputs
#' @description
#' Formats yearly variable (future) Treatment coverages (for each of four possible drug profiles)
#' to input string required for command-line use or as part of the \code{Options} argument in
#' the \code{\link{launch}} function. Use after the word \code{add}.
#'
#' @param years The future (time 0 onwards) output years for the simulation being run.
#' @param drug_0_coverage A vector of treatment coverage inputs for drug profile 0, one for each year specified in years
#' @param drug_1_coverage A vector of treatment coverage inputs for drug profile 1, one for each year specified in years
#' @param drug_2_coverage A vector of treatment coverage inputs for drug profile 2, one for each year specified in years
#' @param drug_3_coverage A vector of treatment coverage inputs for drug profile 3, one for each year specified in years
#' @return A string containing command line options.
#' @examples
#' # Specify years
#' Y <- 0:5
#' # Specify coverage (drugs 0:3)
#' C0 <- rep(0, 6)
#' C1 <- c(0, 0, 0.2, 0.4, 0.6, 0.8)
#' C2 <- rep(0, 6)
#' C3 <- rep(0, 6)
#' # Create input string
#' Treat_input_string <- treat_flexible_input(years = Y, drug_0_coverage = C0, drug_1_coverage = C1,
#'                                            drug_2_coverage = C2, drug_3_coverage = C3)
#' @export
treat_flexible_input <- function(years, drug_0_coverage, drug_1_coverage, drug_2_coverage, drug_3_coverage){

  # Check inputs
  stopifnot(min(years) == 0)
  coverage <- list(drug_1_coverage,drug_1_coverage,drug_1_coverage,drug_1_coverage)
  for(i in 1:4){
    stopifnot(length(years) == length(coverage[[i]]))
    stopifnot(any(coverage[[i]] >= 0))
  }

  treat_cov_options <- 'change_drug 1'
  # Create input text
  for(y in 1:length(years)){
    treat_cov_options <- paste0(treat_cov_options,
                              ' change_drug_', y, ' ', 1,
                              ' change_drug_time_', y, ' ', years[y],
                              ' drug_cov_0_', y, ' ', drug_0_coverage[y],
                              ' drug_cov_1_', y, ' ', drug_1_coverage[y],
                              ' drug_cov_2_', y, ' ', drug_2_coverage[y],
                              ' drug_cov_3_', y, ' ', drug_3_coverage[y])
  }

  return(treat_cov_options)
}

#' @title
#' Flexible SMC inputs
#' @description
#' Formats yearly variable (future) SMC coverages to input string required for command-line use or as part
#' of the \code{Options} argument in the \code{\link{launch}} function. Use after the word \code{add}.
#'
#' @param years The future (time 0 onwards) output years for the simulation being run.
#' @param coverage A vector of SMC coverage inputs, one for each year specified in years
#' @return A string containing command line options.
#' @examples
#' # Specify years
#' Y <- 0:5
#' # Specify coverage
#' C <- c(0, 0, 0.2, 0.4, 0.6, 0.8)
#' # Create input string
#' SMC_input_string <- smc_flexible_input(years = Y, coverage = C)
#'
#' @export
smc_flexible_input <- function(years, coverage){

  # Check inputs
  stopifnot(min(years) == 0)
  stopifnot(length(years) == length(coverage))
  stopifnot(any(coverage >= 0))

  # Cycle through years setting coverage for each
  smc_cov_options <- paste0('smc 1 smc_coverage ', coverage[1], ' smc_max_rounds 1')
  for(i in 2:length(years)){
    smc_cov_options <- paste0(smc_cov_options,
                            ' smc_', i, ' ', 1,
                            ' smc_coverage_', i, ' ', coverage[i],
                            ' smc_start_', i, ' ', years[i],
                            ' smc_max_rounds_', i, ' ', 1)
  }

  return(smc_cov_options)
}

#' @title
#' Flexible SMC inputs with varying rounds
#' @description
#' Formats yearly variable (future) SMC coverages to input string required for command-line use or as part
#' of the \code{Options} argument in the \code{\link{launch}} function. Use after the word \code{add}. This
#' uses annual MDA with SMC age bands to imitate the SMC functionality.  NOTE cannot be used with ipti flexible
#'
#' @param years The future (time 0 onwards) output years for the simulation being run.
#' @param coverage A vector of SMC coverage inputs, one for each year specified in years
#' @param rounds A vector of number of rounds, ond for each year speficied in years
#' @return A string containing command line options.
#' @export
smc_flexible_input2 <- function(years, coverage, rounds){

  # Check inputs
  stopifnot(min(years) == 0)
  stopifnot(length(years) == length(coverage))
  stopifnot(any(coverage >= 0))

  # Cycle through years setting coverage for each
  mda_base_opts <- "mda_drug 3 mda_age0 0.5 mda_age1 5 mda_offset_absolute 0 mda_offset -0.0833333 mda_frequency 0.0833333"
  mda_cov_options <- paste0(mda_base_opts, ' mda 1 mda_coverage ', coverage[1], ' mda_max_rounds ', rounds[1])
  for(i in 2:length(years)){
    mda_cov_options <- paste0(mda_cov_options,
                              ' mda_', i, ' ', 1,
                              ' mda_offset_', i, ' ', -((rounds[i] - 1)/2) / 12,
                              ' mda_coverage_', i, ' ', coverage[i],
                              ' mda_start_', i, ' ', years[i],
                              ' mda_max_rounds_', i, ' ', rounds[i])
  }

  return(mda_cov_options)
}

#' @title
#' Flexible ipti inputs with varying rounds
#' @description
#' Formats yearly variable (future) ipti coverages to input string required for command-line use or as part
#' of the \code{Options} argument in the \code{\link{launch}} function. Use after the word \code{add}. This
#' uses annual MDA with ipti age bands to imitate the ipti functionality. NOTE cannot be used with SMC flexible
#'
#' @param years The future (time 0 onwards) output years for the simulation being run.
#' @param coverage A vector of ipti coverage inputs, one for each year specified in years
#' @param rounds A vector of number of rounds, ond for each year speficied in years
#' @return A string containing command line options.
#' @export
ipti_flexible_input <- function(years, coverage, rounds){

  # Check inputs
  stopifnot(min(years) == 0)
  stopifnot(length(years) == length(coverage))
  stopifnot(any(coverage >= 0))

  # Cycle through years setting coverage for each
  mda_base_opts <- "mda_drug 3 mda_age0 0.25 mda_age1 2 mda_offset_absolute 1 mda_frequency 0.25"
  mda_cov_options <- paste0(mda_base_opts, ' mda 1 mda_coverage ', coverage[1], ' mda_max_rounds ', rounds[1])
  for(i in 2:length(years)){
    mda_cov_options <- paste0(mda_cov_options,
                              ' mda_', i, ' ', 1,
                              ' mda_offset_', i, ' ', -((rounds[i] - 1)/2) / 12,
                              ' mda_coverage_', i, ' ', coverage[i],
                              ' mda_start_', i, ' ', years[i],
                              ' mda_max_rounds_', i, ' ', rounds[i])
  }

  return(mda_cov_options)
}



#' @title
#' Flexible MDA inputs
#' @description
#' Formats yearly variable (future) MDA coverages to input string required for command-line use or as part
#' of the \code{Options} argument in the \code{\link{launch}} function. Use after the word \code{add}.
#'
#' @param years The future (time 0 onwards) output years for the simulation being run.
#' @param coverage A vector of MDA coverage inputs, one for each year specified in years
#' @return A string containing command line options.
#' @examples
#' # Specify years
#' Y <- 0:5
#' # Specify coverage
#' C <- c(0, 0, 0.2, 0.4, 0.6, 0.8)
#' # Create input string
#' MDA_input_string <- mda_flexible_input(years = Y, coverage = C)
#'
#' @export
mda_flexible_input <- function(years, coverage){

  # Check inputs
  stopifnot(min(years) == 0)
  stopifnot(length(years) == length(coverage))
  stopifnot(any(coverage >= 0))

  # Cycle through years setting coverage for each
  mda_cov_options <- paste0('mda 1 mda_coverage ', coverage[1], ' mda_max_rounds 1')
  for(i in 2:length(years)){
    mda_cov_options <- paste0(mda_cov_options,
                            ' mda_', i, ' ', 1,
                            ' mda_coverage_', i, ' ', coverage[i],
                            ' mda_start_', i, ' ', years[i],
                            ' mda_max_rounds_', i, ' ', 1)
  }

  return(mda_cov_options)
}

#' @title
#' Flexible mass pev vaccine inputs
#' @description
#' Formats yearly variable (future) mas pev vaccine coverages to input string required for command-line use or as part
#' of the \code{Options} argument in the \code{\link{launch}} function. Use after the word \code{add}.
#'
#' @param years The future (time 0 onwards) output years for the simulation being run.
#' @param coverage A vector of mass pev vaccine coverage inputs, one for each year specified in years
#' @return A string containing command line options.
#' @examples
#' # Specify years
#' Y <- 0:5
#' # Specify coverage
#' C <- c(0, 0, 0.2, 0.4, 0.6, 0.8)
#' # Create input string
#' mass_pev_input_string <- pev_flexible_input(years = Y, coverage = C)
#'
#' @export
pev_flexible_input <- function(years, coverage){

  # Check inputs
  stopifnot(min(years) == 0)
  stopifnot(length(years) == length(coverage))
  stopifnot(any(coverage >= 0))

  # Cycle through years setting coverage for each
  pev_cov_options<-paste0('mass_pev 1 pev_coverage ', coverage[1], ' pev_max_rounds 1')
  for(i in 2:length(years)){
    pev_cov_options<-paste0(pev_cov_options,
                            ' pev_', i, ' ', 1,
                            ' pev_coverage_', i, ' ', coverage[i],
                            ' pev_start_', i, ' ', years[i],
                            ' pev_max_rounds_', i, ' ', 1)
  }

  return(pev_cov_options)
}

#' @title
#' Flexible epi pev vaccine inputs
#' @description
#' Formats yearly variable (future) epi pev vaccine coverages to input string required for command-line use or as part
#' of the \code{Options} argument in the \code{\link{launch}} function. Use after the word \code{add}.
#'
#' @param years The future (time 0 onwards) output years for the simulation being run.
#' @param coverage A vector of mass pev vaccine coverage inputs, one for each year specified in years
#' @return A string containing command line options.
#' @examples
#' # Specify years
#' Y <- 0:5
#' # Specify coverage
#' C <- c(0, 0, 0.2, 0.4, 0.6, 0.8)
#' # Create input string
#' epi_pev_input_string <- epi_pev_flexible_input(years = Y, coverage = C)
#'
#' @export
epi_pev_flexible_input <- function(years, coverage){

  # Check inputs
  stopifnot(min(years) == 0)
  stopifnot(length(years) == length(coverage))
  stopifnot(any(coverage >= 0))

  # Cycle through years setting coverage for each
  epi_pev_cov_options<-paste0('epi_pev 1 pev_epi_scale_up ', max(years) + 1)
  for(i in 1:length(years)){
    epi_pev_cov_options<-paste0(epi_pev_cov_options,
                                ' pev_epi_coverage', years[i] + 1, ' ', coverage[i])
  }

  return(epi_pev_cov_options)
}



#' ITN resistance time changing functionality
#'
#' @param years vector of years
#' @param resistance resistance estimate
#' @param net_type pyrethroid, pbo, or ig2
#'
#' @return Character options string
#' @export
itn_resistance_flexible_input <- function(years, resistance, net_type){

  stopifnot(net_type %in% c("pyrethroid", "pbo", "ig2"))
  stopifnot(length(years) == length(resistance))

  netindex <- match(net_type, c("pyrethroid", "pbo", "ig2")) - 1

  # Pull resistance pars
  rpar <- r_itn(netindex, resistance)

  # Cycle through years setting coverage for each
  resistance_options <- paste0("change_itn 1 change_itn_time ", years[1],
                               " itn_kill_gamb_ss_1 ", rpar$ERG_d_ITN0[1],
                               " itn_repel_gamb_ss_1 ", rpar$ERG_r_ITN0[1],
                               " itn_kill_fun_1 ", rpar$ERG_d_ITN0[1],
                               " itn_repel_fun_1 ", rpar$ERG_r_ITN0[1],
                               " itn_kill_arab_1 ", rpar$ERG_d_ITN0[1],
                               " itn_repel_arab_1 ", rpar$ERG_r_ITN0[1],
                               " itn_half_life_1 ", rpar$itn_half_life[1])

  for(i in 2:length(years)){
    resistance_options <- paste0(resistance_options,
                                 " change_itn_", i, " 1 change_itn_time_" , i, " ", years[i],
                                 " itn_kill_gamb_ss_", i, " ", rpar$ERG_d_ITN0[i],
                                 " itn_repel_gamb_ss_", i, " ", rpar$ERG_r_ITN0[i],
                                 " itn_kill_fun_", i, " ", rpar$ERG_d_ITN0[i],
                                 " itn_repel_fun_", i, " ", rpar$ERG_r_ITN0[i],
                                 " itn_kill_arab_", i, " ", rpar$ERG_d_ITN0[i],
                                 " itn_repel_arab_", i, " ", rpar$ERG_r_ITN0[i],
                                 " itn_half_life_", i, " ", rpar$itn_half_life[i])
  }

  return(resistance_options)
}

#' ITN resistance time changing functionality
#'
#' @param years vector of years
#' @param resistance resistance estimate
#' @param irs_compound pyrethroid Actellic Sumishield bendiocarb DDT
#'
#' @return Character options string
#' @export
irs_resistance_flexible_input <- function(years, resistance, irs_compound){

  stopifnot(irs_compound %in% c("pyrethroid", "actellic", "sumishield", "bendiocarb", "ddt"))
  stopifnot(length(years) == length(resistance))

  irsindex = match(irs_compound, c("pyrethroid", "actellic", "sumishield", "bendiocarb", "ddt"))

  rpar <- r_irs(irsindex, resistance)

  # Cycle through years setting coverage for each
  resistance_options <- paste0("irs_ellie 1 change_irs 1 change_irs_time ", years[1],
                               " irs_decay_mort1_1 ", rpar$irs_decay_mort1[1],
                               " irs_decay_mort2_1 ", rpar$irs_decay_mort2[1],
                               " irs_decay_succ1_1 ", rpar$irs_decay_succ1[1],
                               " irs_decay_succ2_1 ", rpar$irs_decay_succ2[1],
                               " irs_decay_det1_1 ", rpar$irs_decay_det1[1],
                               " irs_decay_det2_1 ", rpar$irs_decay_det2[1])

  for(i in 2:length(years)){
    resistance_options <- paste0(resistance_options,
                                 " change_irs_", i, " 1 change_irs_time_" , i, " ", years[i],
                                 " irs_decay_mort1_", i, " ", rpar$irs_decay_mort1[i],
                                 " irs_decay_mort2_", i, " ", rpar$irs_decay_mort2[i],
                                 " irs_decay_succ1_", i, " ", rpar$irs_decay_succ1[i],
                                 " irs_decay_succ2_", i, " ", rpar$irs_decay_succ2[i],
                                 " irs_decay_det1_", i, " ", rpar$irs_decay_det1[i],
                                 " irs_decay_det2_", i, " ", rpar$irs_decay_det2[i])
  }

  return(resistance_options)
}
