#' Create bionomics string fro GTS-style vector input
#'
#' @param vectors Vectors data frame for a site
#'
#' @return Bionomics options string
#' @export
bionomics_string <- function(vectors){
  x <- vectors[c("gamb_ss_Q0", "irs_dif_gamb_ss", "gamb_ss_Q_in",
            "gamb_ss_Q_bed", "arab_Q0", "irs_dif_arab", "arab_Q_in", "arab_Q_bed",
            "fun_Q0", "irs_dif_fun", "fun_Q_in", "fun_Q_bed")]
  paste(names(x), x, collapse = " ")
}

#' Create site from GTS-style inputs
#'
#' @param vectors Vectors dataframe for a site
#' @param seasonality Seasonality dataframe for a site
#' @param total_M total_M (if fitted)
#'
#' @return Site file (minimal)
#' @export
site_create <- function(vectors, seasonality, total_M = 0){
  vp <- vectors[c("prop_gamb_ss", "prop_fun", "prop_arab")]
  df1 <- c(vp, seasonality)
  data.frame(par = c(names(df1), "prev", "total_M", "prev_years", "prev_age0", "prev_age1"),
             val = c(unlist(df1), 0, total_M, 3, 2, 10))
}

#' Create resistance parameters from GTS-style inputs
#'
#' @param product pbo net (0 = standard, 1= PBO, 2=G2_nets)
#' @param resistance_range resistance level
#'
#' @return Interventions pars
#' @export
r_itn = function(product, resistance_range){

  metric = 1
  species = 1 ## we do not yet have a distinct effect on different species

  #Assay to hut mortality conversion - median estimates
  param_a = 0.89 ## All 3.57 ## West 3.78 ## East 3.29
  param_b = 0.47 ## All 0.70 ## West 0.73 ## East 0.66

  #Deterency from mortality
  param_c = 2.57 ## All 2.57 ## West 3.04 ## East 1.76
  param_d = 0.49 ## All 0.49 ## West 0.62 ## East 0.10
  param_e = 0.36 ## All 0.36 ## West 0.39 ## East 0.44

  #Success from mortality
  param_f = 4.66 ## All 4.66 ## West 5.18 ## East 3.42
  param_g = 0.04 ## All 0.04 ## West 0.03 ## East 0.01

  #Decay in insecticide non-PBO net
  mup =	array(c(rep(-2.429,3),rep(-2.984025,3),rep(-1.866,3)),c(3,3)) ## ... gam.medians[9]
  rhop =	array(c(rep(-3.007,3),rep(-3.74,3),rep(-2.295,3)),c(3,3)) ## ... gam.medians[10]


  ## The parameters here are from Griffin et al 2010
  ## originally. These will be updated following the durability studies
  ## currently underway in Africa through New Nets Project

  ## The maximum successful feeding probability per feeding attempt
  ## (feeding and not dying) in the absence of interventions
  kp0 = 0.699 ## derived from Lines et al 1987 and Curtis et al 1990

  ## The half-life of the net relative to it's capacity to kill mosquitoes
  ## with the insecticide active ingredient (a pyrethroid) when there is
  ## no resistance in mosquitoes.
  net_halflife = 2.64


  ## The proportion of mosquitoes surviving in the susceptibility bioassay test
  surv_bioassay = resistance_range# a measure of resistance
  # 0 = no resistance
  # 1 = 100% survival in discriminating dose bioassay

  ## Now we work through the probability steps to determine the key input parameters for the model
  ## These probability relationships are determined in Griffin et al 2010 and Churcher et al. 2016

  ## defining the associations for probable outcomes of feeding attempts
  #relationship mortality in bioassay -> hut trial, logit scale
  mort_assay = 1 - surv_bioassay
  mort_huta   = 1/(1+(mort_assay/param_a)^-param_b)

  mort_hut <- rep(NA, length(product))
  for(i in seq_along(product)){
    if(product[i] == 0){
      mort_hut[i] <- mort_huta[i]
    }
    if(product[i] == 1){
      ## pyrethroid-PBO ITNs
      mort_hut[i] <- 1 / (1 + exp(-5.603 * mort_huta[i] -  -1.431))
    }
    if(product[i] == 2){
      ## pyrethroid-chlorfenapyr ITNs
      mort_hut[i] <- 1 / (1 + exp(-4.6637 * mort_huta[i] -  -0.5537 ))
    }
  }



  #relationship hut trial mortality -> deterrence
  det_hut = param_e * exp(param_d * (1 - exp(param_c * (1-mort_hut)))/param_c)

  #relationship hut trial mortality -> success
  suc_hut = 1-exp(param_g * (1 - exp(param_f * (1-mort_hut)))/param_f)

  rep_hut   = 1-suc_hut-mort_hut

  ## Combine to estimate the 3 key probable outcomes of feeding attempts
  ## Here we adjust for those mosquitoes not entering treated huts (determined by deterrence)
  n1n0 = 1-det_hut
  kp1  = n1n0*suc_hut
  jp1  = n1n0*rep_hut+(1-n1n0)
  lp1  = n1n0*mort_hut

  kp1 = ifelse(kp1 > kp0,kp0,kp1) ## Capping impact so max feeding is no bigger than assumed
  ## max feeding for no interventions (kp0 = 0.699, Griffin et al 2010)
  ## (time = 0 time steps after net implementation)
  r_ITN0  = (1-kp1/kp0)*(jp1/(lp1+jp1))	#probability of dying with an encounter with ITN
  d_ITN0  = (1-kp1/kp0)*(lp1/(lp1+jp1))	#probability of repeating behaviour
  s_ITN0  = 1-d_ITN0-r_ITN0             #probability of successfully feeding (surviving and feeding)


  ## Repeat these to determin the maximum and minimum effects which combine to help determine ITN half life
  mort_maxA   = 1/(1+((1)/param_a)^-param_b)

  mort_max <- rep(NA, length(product))
  for(i in seq_along(product)){
    if(product[i] == 0){
      mort_max[i] <- mort_maxA
    }
    if(product[i] == 1){
      ## pyrethroid-PBO ITNs
      mort_max[i] <- 1 / (1 + exp(-5.603 * mort_maxA -  -1.431))
    }
    if(product[i] == 2){
      ## pyrethroid-chlorfenapyr ITNs
      mort_max[i] <-  1 / (1 + exp(-4.6637 * mort_maxA -  -0.5537 ))
    }
  }


  #{halflife}
  my_max_washes_a = mup[species,metric] +rhop[species,metric]*(mort_max-0.5)
  my_max_washes   = log(2)/(exp(my_max_washes_a)/(1+exp(my_max_washes_a)))

  wash_decay_rate_a = mup[species,metric] +rhop[species,metric]*(mort_hut-0.5)
  wash_decay_rate   = log(2)/(exp(wash_decay_rate_a)/(1+exp(wash_decay_rate_a)))
  itn_half_life     = wash_decay_rate/my_max_washes*net_halflife

  ##No need to re-adjust these anymore
  ##Final Parameter estimates for the transmission model
  ERG_d_ITN0 <- d_ITN0
  ERG_s_ITN0 <- s_ITN0
  ERG_r_ITN0 <- 1-ERG_d_ITN0-ERG_s_ITN0

  ## Print out these estimates to a data.frame as the function output
  uncertainty_resistance_params_nets = data.frame(ERG_d_ITN0,ERG_r_ITN0,itn_half_life)

  return(uncertainty_resistance_params_nets)
}



#' Create resistance parameters from GTS-style inputs
#'
#' @param product irs compound 1 is pyrethroid products, 2 is Actellic, 2 is Sumishield, 4 is bendiocarb, 5 is DDT
#' @param resistance_range resistance level
#'
#' @return Interventions pars
#' @export
r_irs = function(product, resistance_range){


  ## IRS parameters and pyrethroid IRS effect with resistance

  ## Bioassay mortality relationships
  ##Using the relationships defined as other chemistries and not accounting for Controls
  alpha1 = -1.059923 ##THIS IS IF DOING DATA REARRANGING AS FUNCTION imp_list_cleaner_f -1.20088# -1.942755
  alpha2 = 0.02387883##0.01878267# 0.03361892
  beta1 =  0.7674771 ##0.8682404# 1.849397
  beta2 =  -0.03166185 ##-0.01735203# -0.04921294
  theta1 = -1.673563 ##-1.672587# -2.071873
  theta2 = -0.0007511497 ##-0.0007890287# 0.02004906


  # ##If AandB              UPDATE THESE...***** ONCE PYRETHROID INDIVIDUAL STUDIES HAVE RUN
  int1 = -2.587528
  int2 =  -0.002989876
  int3 =  -2.95455
  int4 =   0.01200367
  int5 =  -3.917539
  int6 = 0.002780567 ##same as mortality decay...

  grad1 =5.777369
  grad2 = -0.01362388
  grad3 = 5.231271
  grad4 =-0.004870386
  grad5 =8.542869
  grad6 =  0.005316776

  ## Estimating parameters where there is pyrethroid resistance
  ## For any given level of mortality in a bioassay (x) where x=1 indicates all mosquitoes die,
  ## these are linked by the relationship:
  ##  e.g.


  time = 1:365

  x = 1 - resistance_range ##when x is 1 all mosquitoes die

  # death = feed = rep = deter = array(dim=c(365,length(x)))

  irs_params = expand.grid(res_range = resistance_range)

  irs_params <- data.frame(irs_decay_mort1 = rep(NA, length(x)),
                           irs_decay_mort2 = rep(NA, length(x)),
                           irs_decay_succ1 = rep(NA, length(x)),
                           irs_decay_succ2 = rep(NA, length(x)),
                           irs_decay_det1 = rep(NA, length(x)),
                           irs_decay_det2 = rep(NA, length(x)))
  for(i in 1:length(x)){
    if(product[i] == 1 | product[i] == 5){
      temp_mort_1 = grad1 * (1 / (1 + exp(-alpha1 - alpha2 * 100 * x[i]))) + int1
      temp_mort_2 = grad2 * (1 / (1 + exp(-alpha1 - alpha2 * 100 * x[i]))) + int2

      # death[,i] = 1 / (1 + exp(-(temp_mort_1+ temp_mort_2 * time)))

      temp_succ_1 = grad3 * (1 / (1 + exp(-beta1 - beta2 * 100 * x[i]))) + int3
      temp_succ_2 = grad4 * (1 / (1 + exp(-beta1 - beta2 * 100 * x[i]))) + int4

      # feed[,i] = 1 / (1 + exp(-(temp_succ_1 + temp_succ_2 * time)))

      temp_det_1 = grad5 * (1 / (1 + exp(-theta1 - theta2 * 100 * x[i]))) + int5
      temp_det_2 = grad6 * (1 / (1 + exp(-theta1 - theta2 * 100 * x[i]))) + int6

      # deter[,i] = 1 / (1 + exp(-(temp_det_1 + temp_mort_2 * time)))
      irs_params[i,] <- c(temp_mort_1, temp_mort_2, temp_succ_1, temp_succ_2, temp_det_1, temp_det_2)
    }
    if(product[i] == 2){
      # Actellic
      irs_params[i,] <- c(2.024412039,  -0.008887407, -2.222632837, 0.008469928, 1.231733302, -0.008887407)
    }
    if(product[i] == 3){
      # Sumishield
      irs_params[i,] <- c(1.735248, -0.01318361, -2.374664, 0.01146379, -2.643243, -0.01318361)
    }
    if(product[i] == 4){
      # Bendiocarb
      irs_params[i,] <- c(1.094161249, -0.024488819, -1.267712211, 0.019556452, -1.700676448, -0.024488819)
    }
  }

  return(irs_params)
}
