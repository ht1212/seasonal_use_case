
#' @title
#' Format options
#' @description
#' Checks Options input and formats for use with exe. If the input is in the format of a string, no
#' actions occur. If the options are in the format of a data.frame, this is converted into a string
#' for use with the exe.
#'
#' @inheritParams launch
#' @export
format_options <- function(options){

  stopifnot(is.character(options) | is.data.frame(options))

  if(is.character(options)){
    options_formatted <- options
  }

  if(is.data.frame(options)){
    options_formatted <- options_df_to_stf(options)
  }
  return(options_formatted)
}

#' @title
#' Format options data.frame to string
#' @description
#' Takes a input data.frame of options and converts them to a string. The data.frame must contain two columns
#' the first being named \code{par} and the second being named \code{value}. The "add" term can be used by
#' including it in the appropriate position on the \code{par} column, with an associated NA \code{value}.
#'
#' @param options_df The input dataframe of parameters. See description for format.
options_df_to_stf <- function(options_df){
  stopifnot(ncol(options_df) == 2)
  if(!identical(colnames(options_df), c("par", "value"))){
    stop("If specifying the Options argument as a dataframe it must contain two
         columns named par and value")
  }

  if("add" %in% options_df$par){
    index <- which(options_df$par == "add")
    options1 <- options_df[1:(index - 1),]
    options2 <- options_df[(index + 1):nrow(options_df),]

    options_formatted <- paste(options_paste(options1), "add", options_paste(options2))
  } else {
    options_formatted <- paste(options_paste(options_df))
  }
  return(options_formatted)
}

#' @title
#' Create string from data.frame
#' @description
#' Takes an input data.frame and convert to string.
#'
#' @inheritParams options_df_to_stf
options_paste <- function(options_df){
  paste(rbind(as.character(options_df$par), options_df$value), collapse = " ")
}

#' @title
#' Format options string to data.frame
#' @description
#' Takes a input string of options and converts them to a data.frame. The "add" term is dealt with and
#' included as a row in the data.frame.
#'
#' @param options_str The input string of parameters.
#' @export
options_str_to_df <- function(options_str){
  split <- unlist(strsplit(options_str, " "))

  if("add" %in% split){
    add_index <- which(split == "add")
    s1 <- str_to_df(split[1:(add_index - 1)])
    s2 <- str_to_df(split[(add_index + 1):length(split)])
    s <- rbind(s1, c("add", NA), s2)
  } else {
    s <- str_to_df(split)
  }

  return(s)
}

#' @title
#' Create data.frame from a string.
#' @description
#' Takes an input string and convert to data.frame.
#'
#' @inheritParams options_str_to_df
str_to_df <- function(options_str){
  df <- data.frame(par = options_str[c(TRUE, FALSE)],
                 value = as.character(options_str[c(FALSE, TRUE)]),
                 stringsAsFactors = FALSE)
  df
}


