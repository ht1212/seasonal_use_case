#' Hash
#'
#' @param n Lenght of hash
#'
#' @return Character string
hash <- function(n = 25){
  paste0(c(1:10, letters)[sample(1:36, n, replace = TRUE)], collapse = "")
}
