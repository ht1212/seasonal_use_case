#' Named list to df
#'
#' @description Named list and return a dataframe
#'
#' @param df named list of site parameters
#' @return A site file data.frame
list_to_df <- function(df){
  data.frame(names(df), unlist(df))
}

#' Create temp text file
#'
#' @description Take a input file data.frame and saves to a randomly named txt file that will later be deleted
#'
#' @param df A file data.frame
#' @param location The location to save the .txt file (e.g "Root/sites/", or "Root/demog/")
#' @return The file name
df_save <- function(df, location){
  utils::write.table(df, location, row.names = FALSE, col.names = FALSE,
              quote = FALSE, sep = "\t")
}

