
<!-- README.md is generated from README.Rmd. Please edit that file -->
<!-- badges: start -->

[![AppVeyor build
status](https://ci.appveyor.com/api/projects/status/github/mrc-ide/mlgts?branch=master&svg=true)](https://ci.appveyor.com/project/mrc-ide/mlgts)
<!-- badges: end -->
